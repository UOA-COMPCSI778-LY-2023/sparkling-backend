
const SugarIntake = require('../db_models/SugarIntake');

class SugarIntakeService {
  async getDailyIntake(username, date) {
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(startOfDay);
    endOfDay.setDate(endOfDay.getDate() + 1);

    return await SugarIntake.find({
      user: username,
      date: { $gte: startOfDay, $lt: endOfDay }
    });
  }

  async get7DaysIntake(username, date) {
    const endOfDay = new Date(date);
    endOfDay.setHours(0, 0, 0, 0);
    const startOfDay = new Date(endOfDay);
    startOfDay.setDate(endOfDay.getDate() -7);

    return await SugarIntake.find({
      user: username,
      date: { $gte: startOfDay, $lt: endOfDay }
    });
  }

  async addSugarIntake(username, sugarContent, foods){
    const sugarIntake = new SugarIntake({
      user: username,
      sugar: sugarContent, 
      foods: foods
    });
    try{
      await sugarIntake.save();
      return { success: true};
    }catch(error){
      throw error;
    }
  }

}

module.exports = new SugarIntakeService();
