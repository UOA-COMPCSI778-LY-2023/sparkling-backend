
const ScanHistory = require('../db_models/ScanHistory');
const User = require('../db_models/User');
const PackagedFood = require('../db_models/PackagedFood');


class UserService{
    async createUser(newUser){
       try {
        await newUser.save();
        return { success: true}
       } catch (error) {
        throw error;    
       }
    }

    async setSurgarTarget(username, sugarTarget){
        try {
         const user = await User.findOne({username: username});
         if(!user){
            throw new Error('User not found!');
         }
         user.sugarTarget = sugarTarget;
         await user.save();
         return { success: true}
        } catch (error) {
         throw error;    
        }
     }

    async addScanRecord(username, code){
        try {
            const user = await User.findOne({username: username});
            const food = await PackagedFood.findOne({code: code});
            if (!user || !food) {
                throw new Error('User or food not found');
              }
            const history = new ScanHistory({
                user: user._id, 
                food: food._id
            });
            await history.save();
            return {success: true}
        } catch (error) {
         throw error;
        }
     }

     async getScanRecords(username){
        try {
            const users = await User.find({username: username});
            if (!users) {
                throw new Error('User not found');
            }
            const userObjectId = users[0].id;
            const scanHistories = await ScanHistory.find({user: userObjectId}).populate('food');
            return scanHistories;
        } catch (error) {
         throw error;
        }
     }
}

module.exports = new UserService();