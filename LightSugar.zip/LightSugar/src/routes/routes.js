const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const nutritionController = require('../controllers/nutritionController');

router.get('/', (req, res) => {
  res.send('Welcome to Light Surgar!');
});

router.get('/users/:username/sugar-intake/today', userController.getSugarIntakeToday);
router.get('/users/:username/sugar-intake/last-7-days');
router.post('/users/sugar-intake/target', userController.setSurgarTarget);
router.post('/users/sugar-intake', userController.addSurgarIntake);
router.post('/users/scan-record', userController.addScanRecord);
router.get('/users/:username/scan-record', userController.getScanRecords);
router.post('/users/create', userController.createUser);
router.get('/packaged-food/:code', nutritionController.getPackagedFood);
router.post('/packaged-food', nutritionController.addPackagedFood); 


module.exports = router;