const sugarIntakeService = require('../services/sugarIntakeService');
const userService = require('../services/userService');
const User = require('../db_models/User');

class UserController{

  async getSugarIntakeToday(req, res){
    try {
      const username = req.params.username;
      const today = new Date();
      //call sugar intake service to process business logic
      const intakes = await sugarIntakeService.getDailyIntake(username, today);
  
      const totalSugar = intakes.reduce((acc, curr) => acc + curr.sugar, 0);
      res.json({ username, date: today.toISOString().split('T')[0], totalSugar });
    } catch (error) {
      res.status(500).send({ message: "Error retrieving sugar intake data", error });
    }

  }

  async setSurgarTarget(req, res){
    const{username, sugarTarget} = req.body;

    try {
      const result = await userService.setSurgarTarget(username, sugarTarget);
      if(result.success){
        res.status(200).json({message: "Set sugar target success!"});
      }else{
        res.status(400).json({ message: "Set sugar target failed!" });
      }
    } catch (error) {
      res.status(500).json({message: "Error setting sugar target!", error });
    }
  }

  async addSurgarIntake(req, res){
    try{
      const {username, sugarContent, foods} = req.body;  
      const result = await sugarIntakeService.addSugarIntake(username, sugarContent, foods);
      if (result.success) {
      res.status(200).json({message: "Add sugar intake success!"});
      }else{
        res.status(400).json({ message: "Add sugar intake failed!" });
      }
    }catch (error) {
      res.status(500).json({message: "Error adding sugar intake!", error });
    }
  }

  async createUser(req, res){
    try {
      const newUser = new User(req.body);
      const result = await userService.createUser(newUser);
      if (result.success) {
        res.status(200).json({ message: "User creating success!"});
      }else{
        res.status(400).json({ message: "User creating failed!" });
      }
    } catch (error) {
      res.status(500).json({message: "Error creating new user", error });
    }
  }

  async addScanRecord(req, res){
    const {username, code} = req.body
    try {
      const result = await userService.addScanRecord(username, code);
      if (result.success) {
        res.status(200).json({message: "Add scan record success!"});
      }else{
        res.status(400).json({ message: "Add scan record failed!" });
      }
    } catch (error) {
      res.status(500).json({message: "Error adding scan record!", error });
    }
  }

  async getScanRecords(req, res){
    const username = req.params.username;
    try {
      const scanHistories = await userService.getScanRecords(username);
      res.status(200).json(scanHistories);
    } catch (error) {
      res.status(500).json({message: "Error getting scan record!", error });
    }
  }
}

module.exports = new UserController();
