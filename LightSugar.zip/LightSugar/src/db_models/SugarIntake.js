const mongoose = require('mongoose');

const sugarIntakeSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  date: {
    type: Date, 
    default: Date.now
  },

  foods: [{
    food: {    
      type: mongoose.Schema.Types.ObjectId,
      ref: 'PackagedFoodNutritionInfo',
      required: true
    },
    servingSize: {
      type: Number,
      required: true
    },
    unit: {
      type: String,
      enum: ['unit', 'serving', 'milliliter', 'gram'],
      required: true
    },
  }],
  sugar: {
    type: Number, 
    required: true
  },
});

const SugarIntake = mongoose.model('SugarIntake', sugarIntakeSchema);
module.exports = SugarIntake;
